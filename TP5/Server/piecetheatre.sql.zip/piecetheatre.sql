-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Dim 17 Novembre 2013 à 16:39
-- Version du serveur: 5.0.51
-- Version de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de données: `piecetheatre`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `pieces`
-- 

CREATE TABLE `pieces` (
  `name_p` varchar(10) collate latin1_bin NOT NULL,
  `number_p` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

-- 
-- Contenu de la table `pieces`
-- 

INSERT INTO `pieces` VALUES (0x4c6170696e, 1);
INSERT INTO `pieces` VALUES (0x436869656e, 4);
INSERT INTO `pieces` VALUES (0x43686174, 20);
INSERT INTO `pieces` VALUES (0x506572726f71756574, 5);
INSERT INTO `pieces` VALUES (0x53696e6765, 4);
